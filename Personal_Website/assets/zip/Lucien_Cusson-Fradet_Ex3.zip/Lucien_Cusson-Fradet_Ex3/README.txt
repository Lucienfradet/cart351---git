Running index.php allows to experience the website.

Most of the map function and UI was borrowed from one of my other project.
The PHP and SQLite implementation are all new.